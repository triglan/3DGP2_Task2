#pragma once
typedef void(*Start_Mode)(void);

extern Start_Mode StartMode;